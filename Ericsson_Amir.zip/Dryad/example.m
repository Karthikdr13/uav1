clear all
close all
clc

LW1_long = -78.69594208319383;
LW1_lat = 35.727487047024084; 
LW1_alt = 10;
%% files for yaw 45
% Detect import options for the CSV file
opts = detectImportOptions('yaw45/inputf2_rsrp_with_header.csv', 'VariableNamingRule', 'preserve');

% Set the data type for the second column to datetime
opts = setvartype(opts, 2, 'datetime');

% Specify the datetime format for the second column
datetimeFormat = 'yyyy-MM-dd HH:mm:ss.SSS';
opts = setvaropts(opts, 2, 'InputFormat', datetimeFormat);

throughput_45 = readtable('yaw45/input_throughput_with_header.csv', opts);
LTE_RSRP_45 = readtable('yaw45/inputf1_rsrp_with_header.csv', opts);
LTE_SINR_45 = readtable('yaw45/inputf1_sinr_with_header.csv', opts);
% NR_CQI_45 = readtable('yaw45/inputf2_cqi_with_header.csv', opts);
% NR_MCS_45 = readtable('yaw45/inputf2_mcs_with_header.csv', opts);
% NR_RI_45 = readtable('yaw45/inputf2_ri_with_header.csv', opts);
NR_RSRP_45 = readtable('yaw45/inputf2_rsrp_with_header.csv', opts);
NR_SINR_45 = readtable('yaw45/inputf2_sinr_with_header.csv', opts);

%% examples

%% RSRP results
% 3D scatter LED
x = LTE_RSRP_45.Longitude;  
y = LTE_RSRP_45.Latitude;
z = LTE_RSRP_45.Altitude;
c = LTE_RSRP_45.("LTE RSRP");
figure;
scatter3(x, y, z, 36, c, 'filled');  % '36' is the marker size, 'c' is the color
xlabel('Longitude');
ylabel('Latitude');
zlabel('Altitude');
colorbar;
colormap jet;
% Pinpoint the reference location with a special marker
hold on;
scatter3(LW1_long, LW1_lat, LW1_alt, 200, 'r', 'p', 'filled'); % 'p' is for pentagram (pinpoint), 'r' makes it red
hold off;
title('3D Scatter Plot for LTE RSRP');


% 3D scatter NR
x = NR_RSRP_45.Longitude;  
y = NR_RSRP_45.Latitude;
z = NR_RSRP_45.Altitude;
c = NR_RSRP_45.("NR RSRP");
figure;
scatter3(x, y, z, 36, c, 'filled');  % '36' is the marker size, 'c' is the color
xlabel('Longitude');
ylabel('Latitude');
zlabel('Altitude');
colorbar;
colormap jet;
% Pinpoint the reference location with a special marker
hold on;
scatter3(LW1_long, LW1_lat, LW1_alt, 200, 'r', 'p', 'filled'); % 'p' is for pentagram (pinpoint), 'r' makes it red
hold off;
title('3D Scatter Plot for NR RSRP');

%% Distance vs time (NR)
% Create a reference ellipsoid object for WGS84
wgs84 = referenceEllipsoid('wgs84', 'm'); % 'm' specifies the unit of measure in meters

% Calculate horizontal distances using the WGS84 ellipsoid model
[dist, az] = distance(y, x, LW1_lat, LW1_long, wgs84);

% Calculate vertical distances
vertical_dist = abs(z - LW1_alt);

% Calculate 3D distances using Pythagorean theorem
total_dist = sqrt(dist.^2 + vertical_dist.^2);

NR_time = NR_RSRP_45.("Time and date");
% Calculate the time difference from the first element
firstTime = NR_time(1);
timeDifferences_NR = NR_time - firstTime;
% Convert the time differences to seconds
timeDifferencesInSeconds_NR = seconds(timeDifferences_NR);
figure
plot(timeDifferencesInSeconds_NR, total_dist)
xlabel('Time (s)');
ylabel('Distance (m)');
title('3D Distance vs time');


%% RSRP vs. time
Time_LTE = LTE_RSRP_45.("Time and date");
timeDifferences_LTE = Time_LTE - Time_LTE(1);
timeDifferencesInSeconds_LTE = seconds(timeDifferences_LTE);

figure
plot(timeDifferencesInSeconds_LTE, LTE_RSRP_45.("LTE RSRP"))
hold on
plot(timeDifferencesInSeconds_NR, NR_RSRP_45.("NR RSRP"))
grid on
xlabel('Time (s)');
ylabel('RSRP (dBm)');
title('RSRP for LTE and NR');


%% SINR vs. time
Time_LTE = LTE_SINR_45.("Time and date");
timeDifferences_LTE = Time_LTE - Time_LTE(1);
timeDifferencesInSeconds_LTE = seconds(timeDifferences_LTE);

Time_NR = NR_SINR_45.("Time and date");
timeDifferences_NR = Time_NR - Time_NR(1);
timeDifferencesInSeconds_NR = seconds(timeDifferences_NR);

figure
plot(timeDifferencesInSeconds_LTE, LTE_SINR_45.("LTE SINR"))
hold on
plot(timeDifferencesInSeconds_NR, NR_SINR_45.("NR SINR"))
grid on
xlabel('Time (s)');
ylabel('SINR (dB)');
title('SINR for LTE and NR');

%% PDF and CDF of RSRP
%PDF
RSRP_NR = NR_RSRP_45.("NR RSRP"); 
RSRP_LTE = LTE_RSRP_45.("LTE RSRP"); 

[f_pdf1, x_pdf1] = ksdensity(RSRP_NR);
figure
plot(x_pdf1, f_pdf1, 'LineWidth', 2); % Increase line width to 2
hold on;

% PDF estimation for data2
[f_pdf2, x_pdf2] = ksdensity(RSRP_LTE);
plot(x_pdf2, f_pdf2, 'LineWidth', 2); % Increase line width to 2
hold off;

title('RSRP PDF');
xlabel('Data Values');
ylabel('Probability Density');
legend('NR', 'LTE');

% CDF
figure;
[f_cdf1, x_cdf1] = ksdensity(RSRP_NR, 'Function', 'cdf');
plot(x_cdf1, f_cdf1, 'LineWidth', 2); % Increase line width to 2

hold on;
% CDF estimation for data2
[f_cdf2, x_cdf2] = ksdensity(RSRP_LTE, 'Function', 'cdf');
plot(x_cdf2, f_cdf2, 'LineWidth', 2); % Increase line width to 2
hold off;
title('RSRP CDF');
xlabel('Data Values');
ylabel('Cumulative Probability');
legend('NR', 'LTE');



%% files for yaw 315
% Detect import options for the CSV file
opts = detectImportOptions('yaw315/inputf2_rsrp_with_header.csv', 'VariableNamingRule', 'preserve');

% Set the data type for the second column to datetime
opts = setvartype(opts, 2, 'datetime');

% Specify the datetime format for the second column
datetimeFormat = 'yyyy-MM-dd HH:mm:ss.SSS';
opts = setvaropts(opts, 2, 'InputFormat', datetimeFormat);

throughput_315 = readtable('yaw315/input_throughput_with_header.csv', opts);
LTE_RSRP_315 = readtable('yaw315/inputf1_rsrp_with_header.csv', opts);
LTE_SINR_315 = readtable('yaw315/inputf1_sinr_with_header.csv', opts);
% NR_CQI_315 = readtable('yaw315/inputf2_cqi_with_header.csv', opts);
% NR_MCS_315 = readtable('yaw315/inputf2_mcs_with_header.csv', opts);
% NR_RI_315 = readtable('yaw315/inputf2_ri_with_header.csv', opts);
NR_RSRP_315 = readtable('yaw315/inputf2_rsrp_with_header.csv', opts);
NR_SINR_315 = readtable('yaw315/inputf2_sinr_with_header.csv', opts);

%% examples

%% RSRP results
% 3D scatter LED
x = LTE_RSRP_315.Longitude;  
y = LTE_RSRP_315.Latitude;
z = LTE_RSRP_315.Altitude;
c = LTE_RSRP_315.("LTE RSRP");
figure;
scatter3(x, y, z, 36, c, 'filled');  % '36' is the marker size, 'c' is the color
xlabel('Longitude');
ylabel('Latitude');
zlabel('Altitude');
colorbar;
colormap jet;
% Pinpoint the reference location with a special marker
hold on;
scatter3(LW1_long, LW1_lat, LW1_alt, 200, 'r', 'p', 'filled'); % 'p' is for pentagram (pinpoint), 'r' makes it red
hold off;
title('3D Scatter Plot for LTE RSRP');


% 3D scatter NR
x = NR_RSRP_315.Longitude;  
y = NR_RSRP_315.Latitude;
z = NR_RSRP_315.Altitude;
c = NR_RSRP_315.("NR RSRP");
figure;
scatter3(x, y, z, 36, c, 'filled');  % '36' is the marker size, 'c' is the color
xlabel('Longitude');
ylabel('Latitude');
zlabel('Altitude');
colorbar;
colormap jet;
% Pinpoint the reference location with a special marker
hold on;
scatter3(LW1_long, LW1_lat, LW1_alt, 200, 'r', 'p', 'filled'); % 'p' is for pentagram (pinpoint), 'r' makes it red
hold off;
title('3D Scatter Plot for NR RSRP');

%% Distance vs time (NR)
% Create a reference ellipsoid object for WGS84
wgs84 = referenceEllipsoid('wgs84', 'm'); % 'm' specifies the unit of measure in meters

% Calculate horizontal distances using the WGS84 ellipsoid model
[dist, az] = distance(y, x, LW1_lat, LW1_long, wgs84);

% Calculate vertical distances
vertical_dist = abs(z - LW1_alt);

% Calculate 3D distances using Pythagorean theorem
total_dist = sqrt(dist.^2 + vertical_dist.^2);

NR_time = NR_RSRP_315.("Time and date");
% Calculate the time difference from the first element
firstTime = NR_time(1);
timeDifferences_NR = NR_time - firstTime;
% Convert the time differences to seconds
timeDifferencesInSeconds_NR = seconds(timeDifferences_NR);
figure
plot(timeDifferencesInSeconds_NR, total_dist)
xlabel('Time (s)');
ylabel('Distance (m)');
title('3D Distance vs time');


%% RSRP vs. time
Time_LTE = LTE_RSRP_315.("Time and date");
timeDifferences_LTE = Time_LTE - Time_LTE(1);
timeDifferencesInSeconds_LTE = seconds(timeDifferences_LTE);

figure
plot(timeDifferencesInSeconds_LTE, LTE_RSRP_315.("LTE RSRP"))
hold on
plot(timeDifferencesInSeconds_NR, NR_RSRP_315.("NR RSRP"))
grid on
xlabel('Time (s)');
ylabel('RSRP (dBm)');
title('RSRP for LTE and NR');


%% SINR vs. time
Time_LTE = LTE_SINR_315.("Time and date");
timeDifferences_LTE = Time_LTE - Time_LTE(1);
timeDifferencesInSeconds_LTE = seconds(timeDifferences_LTE);

Time_NR = NR_SINR_315.("Time and date");
timeDifferences_NR = Time_NR - Time_NR(1);
timeDifferencesInSeconds_NR = seconds(timeDifferences_NR);

figure
plot(timeDifferencesInSeconds_LTE, LTE_SINR_315.("LTE SINR"))
hold on
plot(timeDifferencesInSeconds_NR, NR_SINR_315.("NR SINR"))
grid on
xlabel('Time (s)');
ylabel('SINR (dB)');
title('SINR for LTE and NR');

%% PDF and CDF of RSRP
%PDF
RSRP_NR = NR_RSRP_315.("NR RSRP"); 
RSRP_LTE = LTE_RSRP_315.("LTE RSRP"); 

[f_pdf1, x_pdf1] = ksdensity(RSRP_NR);
figure
plot(x_pdf1, f_pdf1, 'LineWidth', 2); % Increase line width to 2
hold on;

% PDF estimation for data2
[f_pdf2, x_pdf2] = ksdensity(RSRP_LTE);
plot(x_pdf2, f_pdf2, 'LineWidth', 2); % Increase line width to 2
hold off;

title('RSRP PDF');
xlabel('Data Values');
ylabel('Probability Density');
legend('NR', 'LTE');

% CDF
figure;
[f_cdf1, x_cdf1] = ksdensity(RSRP_NR, 'Function', 'cdf');
plot(x_cdf1, f_cdf1, 'LineWidth', 2); % Increase line width to 2

hold on;
% CDF estimation for data2
[f_cdf2, x_cdf2] = ksdensity(RSRP_LTE, 'Function', 'cdf');
plot(x_cdf2, f_cdf2, 'LineWidth', 2); % Increase line width to 2
hold off;
title('RSRP CDF');
xlabel('Data Values');
ylabel('Cumulative Probability');
legend('NR', 'LTE');

